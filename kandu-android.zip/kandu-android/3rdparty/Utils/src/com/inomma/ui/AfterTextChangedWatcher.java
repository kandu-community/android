package com.inomma.ui;

import android.text.TextWatcher;

public abstract class AfterTextChangedWatcher implements TextWatcher
{

	@Override
	public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3)
	{
	}

	@Override
	public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3)
	{
	}

}
