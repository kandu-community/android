package com.inomma.ui.fragments.tabfragments;

public interface OnTabChangeListener {
	public void onTabChange(int index);
}
