package com.inomma.utils;

public class ValidationUtils {
	
	public static boolean validateEmail(String email)
	{
		return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
	}

}
