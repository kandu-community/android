package com.inomma.kandu.server;

public enum RequestMethod {

	POST,GET,PUT;
}
