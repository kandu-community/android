package com.inomma.kandu.model;

import java.util.List;

public class Icon {

	
}
