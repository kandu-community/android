package com.inomma.kandu.ui;

public interface ActivityRequestCodes {
	
	public static final int CHOOSE_FILE = 10001;
}
